package Student_info;

public class attendance {
    int attendance_id;
    Student student_id;
    Course course_id;
    String date;
    String status;

    public attendance( int attendance_id,Student student_id,Course course_id ,String date,String status) {
        this.attendance_id = attendance_id;
        this.student_id = student_id;
        this.course_id = course_id;
        this.date=date;
        this.status=status;
    } 
    public int getAttendance_id() {
        return attendance_id;
    }
    public void setAttendance_id(int attendance_id) {
        this.attendance_id = attendance_id;
    }
    public Student getStudent_id() {
        return student_id;
    }
    public void setStudent_id(Student student_id) {
        this.student_id = student_id;
    }
    public Course getCourse_id() {
        return course_id;
    }
    public void setCourse_id(Course course_id) {
        this.course_id = course_id;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public void display() {
        System.out.println("Attendance_id:"+attendance_id);
        student_id.display();
        course_id.display();
        System.out.println("Status: " + status);
        System.out.println("Date: " + date);
    }
}
