package Student_info;

public abstract class grade {
    Student student_id;
    int grade_id;
    Course course_id;
    String score;

    public grade(Student student_id, int grade_id, Course course_id, String score) {
        this.student_id = student_id;
        this.grade_id = grade_id;
        this.course_id = course_id;
        this.score=score;
    }
    
 
    public Student getStudent_id() {
        return student_id;
    }


    public void setStudent_id(Student student_id) {
        this.student_id = student_id;
    }


    public int getGrade_id() {
        return grade_id;
    }


    public void setGrade_id(int grade_id) {
        this.grade_id = grade_id;
    }


    public Course getCourse_id() {
        return course_id;
    }


    public void setCourse_id(Course course_id) {
        this.course_id = course_id;
    }


    public String getScore() {
        return score;
    }


    public void setScore(String score) {
        this.score = score;
    }


    public void display() {
        System.out.println("Grade:"+grade_id);
        course_id.display();
        student_id.display();
        System.out.println("score: " + score);
    }
    
}
