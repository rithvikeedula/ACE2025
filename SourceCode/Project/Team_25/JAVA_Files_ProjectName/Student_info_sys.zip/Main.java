package Student_info;

public class Main { public static void main(String[] args) {
    Student student = new Student("");
    Course course = new Course("");
    enrollment Enrollment = new enrollment("");
    attendance Attendance = new attendance();
    grade Grade = new grade("");
    Schedule schedule = new Schedule();
    faculty Faculty = new faculty();
    Department department = new Department("");
    Transcript transcript = new Transcript("");
    Fee fee = new Fee("");

    student.display();
    System.out.println();
    course.display();
    System.out.println();
    Enrollment.display();
    System.out.println();
    Attendance.display();
    System.out.println();
    Grade.display();
    System.out.println();
    schedule.display();
    System.out.println();
    Faculty.display();
    System.out.println();
    department.display();
    System.out.println();
    transcript.display();
    System.out.println();
    fee.display();
}
}
