package Student_info;

public class Transcription {
    Student student_id;
    Course course_id;
    grade grade;
    int transcript_id;

    public Transcription(Student student_id, Course course_id, int transcript_id,grade grade) {
        this.student_id = student_id;
        this.course_id = course_id;
        this.grade = grade;
        this.transcript_id=transcript_id;
    }
    

    public Student getStudent_id() {
        return student_id;
    }


    public void setStudent_id(Student student_id) {
        this.student_id = student_id;
    }


    public Course getCourse_id() {
        return course_id;
    }


    public void setCourse_id(Course course_id) {
        this.course_id = course_id;
    }


    public grade getGrade() {
        return grade;
    }


    public void setGrade(grade grade) {
        this.grade = grade;
    }


    public int getTranscript_id() {
        return transcript_id;
    }


    public void setTranscript_id(int transcript_id) {
        this.transcript_id = transcript_id;
    }


    public void display() {
        student_id.display();
        course_id.display();
        grade.display();
        System.out.println("Transcript:"+transcript_id);
    }
}

